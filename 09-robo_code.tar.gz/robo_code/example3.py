import numpy as np
from tracker import RobotTracker
import matplotlib.pyplot as plt

# Do a bunch of simulations of robot movement
tracker = RobotTracker(process_var = 0.005, measure_var = 0.1**2)

for i in range(2):
    for j in range(5):
        x, x_real = tracker.predict_plot(np.array([1.,0.]))

    x_m, x, x_real = tracker.measure_plot()
plt.show()
