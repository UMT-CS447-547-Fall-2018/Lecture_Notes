import numpy as np

### A bad robot that you can command to move!
###################################################

class Robot(object):

    def __init__(self, x, y, process_var = 0.15, measure_var = 6.**2):
        # Number of moves
        self.moves = 0
        # Robot x position
        self.pos = np.array([x, y])
        # Movement noise variance
        self.process_P = np.array([[process_var, 0.], [0., process_var]])
        # Measurement noise variance
        self.measure_P = np.array([[measure_var, 0.], [0., measure_var]])

        
    # Move one unit in a given direction 
    def move(self, direction):
        self.moves += 1
        # Normalize vector
        direction /= np.linalg.norm(direction)
        self.pos[:] = np.random.multivariate_normal(self.pos + direction, self.process_P, 1)[0]
        return self.pos.copy()

    
    # Take a noisy measurement of position
    def measure_pos(self):
        return np.random.multivariate_normal(self.pos, self.measure_P, 1)[0]
