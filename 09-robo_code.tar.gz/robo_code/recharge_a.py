import numpy as np
from robot import Robot


### Head blindly towards the recharge zone and hope we hit it (Model only)
###############################################################

# Recharge zone position 
recharge_pos = np.array([75., 20.])
# Recharge radisu
recharge_rad = 1.5
# Number of successes
successes = 0

# Run a bunch of simulations
for k in range(1500):
    robot = Robot(0., 0.)
    # Direction to the recharge zone
    d = recharge_pos.copy()
    i = 0
    success = False 

    while i < 18 and np.linalg.norm(robot.pos - recharge_pos) > recharge_rad:

        # Make 5 moves (this will make sense later)
        for j in range(5):
            robot.move(d)
            # Move in the direction we think the recharge station is
            if np.linalg.norm(robot.pos - recharge_pos) <= recharge_rad:
                #rint "success"
                success = True
                break 

        i += 1

    if success:
        print "Success!"
        successes += 1
    else :
        print "Failure"

print(successes / 1500.)
