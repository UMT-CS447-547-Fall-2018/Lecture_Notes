import numpy as np
from tracker import RobotTracker
import matplotlib.pyplot as plt

# Do a bunch of simulations of robot movement
tracker = RobotTracker()
for i in range(10):
    x, x_real = tracker.predict_plot(np.array([1.,0.]))

plt.show()
