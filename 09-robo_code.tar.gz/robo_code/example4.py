import numpy as np
import numpy as np
from robot import Robot
from tracker import RobotTracker
import matplotlib.pyplot as plt


### Guide the robot to the recharge zone using the filter and plot position
###############################################################

# Recharge zone position 
recharge_pos = np.array([75., 20.])
# Recharge radisu
recharge_rad = 1.5
# Number of successes
successes = 0
# Robot tracker 
tracker = RobotTracker(measure_var = 2.**2)
i = 0

# Plot the recharge zone
circle = plt.Circle(recharge_pos, recharge_rad, color='y')
plt.gcf().gca().add_artist(circle)

while i < 25 and np.linalg.norm(tracker.robot.pos - recharge_pos) > recharge_rad:
    # Try to move to the recharge zone
    x_m, x, x_real = tracker.measure_plot()
    # Get direction based on predicted position
    d = recharge_pos - x

    for j in range(5):
        # Make a move and predict location
        x, x_real = tracker.predict_plot(d)
        if np.linalg.norm(tracker.robot.pos - recharge_pos) <= recharge_rad:
            success = True
            break 
        # Update direction to move based on new predicted location 
        d = recharge_pos - x

    i += 1

plt.show()
