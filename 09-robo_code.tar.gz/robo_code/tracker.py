import numpy as np
from robot import Robot
import matplotlib.pyplot as plt
from filterpy.stats import plot_covariance_ellipse

# A Kalman filter we can use to track the robot
###########################################################

class RobotTracker(object):
    def __init__(self, process_var = 0.15, measure_var = 6.**2):
        # The robot I'm going to track
        self.robot = Robot(0.0, 0.0, process_var, measure_var)
        # Estimate robot position
        self.x = np.array([0., 0.])
        # Identity
        self.I = np.array([[1., 0.], [0., 1.]])
        # Position covariance
        self.P = 1e-12 * self.I[:]
        # Movement noise variance
        self.Q = self.robot.process_P[:]
        # Measurement noise variance
        self.R = self.robot.measure_P[:]
        

    # Command the robot to move, and predict it's new position
    def predict(self, direction):

        # Command it to move!
        self.robot.move(direction)

        ### Predict the robot's position
        #################################################################
        
        # Predicted position of the robot
        self.x += (direction / np.linalg.norm(direction))
        # Prediction uncertainty
        self.P += self.Q

        return self.x.copy(), self.P.copy()


    # Plot the estimated and true position after a move command
    def predict_plot(self, direction):
        x, P = self.predict(direction)
        x_real = self.robot.pos.copy()

        # Real position 
        plt.plot(x_real[0], x_real[1], 'k^', ms = 10)
        # Estimated position
        el = plot_covariance_ellipse(x, P, fc='k', alpha=0.1, 
           std=[1, 2])

        return x, x_real
        
        
    # Take a noisy GPS measurement of robot's position, and use it
    # to update our belief about where the robot is 
    def measure(self):
        
        # Take a noisy measurement of the robot's position
        x_m = self.robot.measure_pos()

        # Refine the estimated position by incorporating the measurement
        #################################################################

        # To make formulas cleaner...
        x_bar = self.x
        P_bar = self.P
        R = self.R
        I = self.I
        
        # Compute the innovation
        y = (x_m - x_bar)
        # Compute the Kalman gain
        K = np.dot(P_bar, np.linalg.inv(P_bar + R))
        # New estimated position
        self.x = x_bar + np.dot(K, y)
        self.P = np.dot(self.I - K, P_bar)

        return x_m, self.x.copy(), self.P.copy()


    # Plot the estimated and true position after a GPS measurement
    def measure_plot(self):
        x_m, x, P = self.measure()
        x_real = self.robot.pos.copy()

        # Real position
        plt.plot(x_real[0], x_real[1], 'k^', ms = 10)
        # Noisy measurement
        plt.plot(x_m[0], x_m[1], 'ro')
        # Plot estimated position
        el = plot_covariance_ellipse(x, P, fc='r', alpha=0.2, 
           std=[2])

        return x_m, x, x_real
