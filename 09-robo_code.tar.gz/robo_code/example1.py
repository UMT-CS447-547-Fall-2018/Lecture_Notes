import numpy as np
from robot import Robot
import matplotlib.pyplot as plt

# Do a bunch of simulations of robot movement
for k in range(2000):
    print k
    robot = Robot(0., 0.)
    pos = robot.move(np.array([1.,0.]))
    plt.plot(pos[0], pos[1], 'ko')

plt.show()
