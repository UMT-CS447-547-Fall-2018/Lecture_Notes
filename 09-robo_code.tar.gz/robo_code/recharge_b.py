import numpy as np
from robot import Robot


### Use GPS only to guide robot
###############################################################

# Recharge zone position 
recharge_pos = np.array([75., 20.])
# Recharge radisu
recharge_rad = 1.5
# Number of successes
successes = 0

# Run a bunch of simulations
for k in range(1500):
    robot = Robot(0., 0.)
    i = 0
    success = False 

    while i < 18 and np.linalg.norm(robot.pos - recharge_pos) > recharge_rad:

        # Take a GPS measurement of position
        m_pos = robot.measure_pos()
        # Direction to the recharge station based on GPS reading
        d = recharge_pos - m_pos
        
        # Make 5 moves (this will make sense later)
        for j in range(5):
            robot.move(d)
            # Move in the direction we think the recharge station is
            if np.linalg.norm(robot.pos - recharge_pos) <= recharge_rad:
                success = True
                break 

        i += 1

    if success:
        print "Success!"
        successes += 1
    else :
        print "Failure"

print(successes / 1500.)
