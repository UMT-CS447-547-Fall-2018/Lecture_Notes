import numpy as np
import numpy as np
from robot import Robot
from tracker import RobotTracker


### Use the Kalman filter to guide the robot.
###############################################################

# Recharge zone position 
recharge_pos = np.array([75., 20.])
# Recharge radisu
recharge_rad = 1.5
# Number of successes
successes = 0

for k in range(1500):
    tracker = RobotTracker()
    i = 0
    success = False

    while i < 18 and np.linalg.norm(tracker.robot.pos - recharge_pos) > recharge_rad:
        # Try to move to the recharge zone
        x_m, x, x_real = tracker.measure()
        # Get direction based on estimated position
        d = recharge_pos - x

        for j in range(5):
            # Make a move and predict location
            x, x_real = tracker.predict(d)
            if np.linalg.norm(tracker.robot.pos - recharge_pos) <= recharge_rad:
                success = True
                break 
            # Update direction to move based on new predicted location 
            d = recharge_pos - x

        i += 1

    if success:
        print "Success!"
        successes += 1
    else :
        print "Failure"

print(successes / 1500.)
